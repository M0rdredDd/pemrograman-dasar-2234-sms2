public class data {

// nik nama usia alamt hobi status ttl cetak dengan bantuan \n

    public static void main (String[]args ) {
        String nim = "22410100034";
        String nama = "fandy ardiansyah";
        String usia = "18";
        String alamat = "tulangan";
        String hobi = "turu";
        String status = "hidup";
        String ttl = "sidoarjo 12 04 2004";

        System.out.print("nim  " +nim+ "\nnama  " +nama+ "\nusia " +usia+ "\nalamat "+ alamat +"\nhobi "+ hobi +"\nstatus "+status+"\nttl "+ ttl);
    }







}